import serial
import re
import requests
import time

# ---------------- CONFIG ----------------
PORT = "COM4"
BAUD = 115200
BLYNK_TOKEN = "oKNNy7QRFFqLZjOKtLjZ4lVLo0VbPhQS"
MODEL_PATH = "svm_model.pkl"
ACZ_LOW = 14000
ACX_HIGH = 8000
ACY_HIGH = 8000
RPM_HIGH = 7000

ACZ_WARNING = 15000
ACXY_WARNING = 5000
RPM_WARNING = 4000
# ----------------------------------------

ser = serial.Serial(PORT, BAUD, timeout=1)
print("Blynk stable monitoring on", PORT)

session = requests.Session()  # 🔴 reuse connection

FEATURE_COLUMNS = [
    "voltage",
    "rpm",
    "temperature",
    "vibration",
    "acx",
    "acy",
    "acz"
]

sample = {k: None for k in FEATURE_COLUMNS}

last_push_time = 0
PUSH_INTERVAL = 1.5  # 🔴 slow down cloud push


# ---------- BLYNK WRITE ----------
def blynk_write(pin, value):
    try:
        url = f"https://blynk.cloud/external/api/update?token={BLYNK_TOKEN}&{pin}={value}"
        session.get(url, timeout=1)
    except:
        pass  # 🔴 never block


def send_to_blynk(values, status, health_code):
    blynk_write("V0", status)
    blynk_write("V1", int(values["rpm"]))
    blynk_write("V2", int(values["acz"]))
    blynk_write("V3", health_code)
    blynk_write("V4", round(values["voltage"], 2))
    blynk_write("V5", round(values["temperature"], 2))
    blynk_write("V6", int(values["acx"]))
    blynk_write("V7", int(values["acy"]))
    blynk_write("V8", values["vibration"])


# ---------------- MAIN LOOP ----------------
while True:
    try:
        line = ser.readline().decode(errors="ignore").strip()
        if not line:
            continue

        print("Raw:", line)

        if "DATA" in line:
            sample = {k: None for k in sample}
            continue

        # -------- PARSING --------
        if "Voltage:" in line:
            sample["voltage"] = float(re.findall(r"-?\d+\.?\d*", line)[-1])

        elif "RPM:" in line:
            sample["rpm"] = float(re.findall(r"-?\d+\.?\d*", line)[-1])

        elif "Temperature" in line:
            sample["temperature"] = float(re.findall(r"-?\d+\.?\d*", line)[-1])

        elif "Vibration:" in line:
            sample["vibration"] = 0 if "No Vibration" in line else 1

        elif "AcX:" in line:
            nums = re.findall(r"-?\d+", line)
            sample["acx"] = float(nums[0])
            sample["acy"] = float(nums[1])
            sample["acz"] = float(nums[2])

        # -------- WHEN FULL SAMPLE READY --------
        if all(v is not None for v in sample.values()):

            acx = abs(sample["acx"])
            acy = abs(sample["acy"])
            acz = sample["acz"]
            rpm = sample["rpm"]
            vib = sample["vibration"]

            # ---------- RULE LOGIC ----------
            if (
                acz < ACZ_LOW or
                acx > ACX_HIGH or
                acy > ACY_HIGH or
                vib == 1 or
                rpm > RPM_HIGH
            ):
                status = "MAINTENANCE REQUIRED"
                health_code = 2

            elif (
                acz < ACZ_WARNING or
                acx > ACXY_WARNING or
                acy > ACXY_WARNING or
                rpm > RPM_WARNING
            ):
                status = "WARNING"
                health_code = 1

            else:
                status = "HEALTHY"
                health_code = 0

            print("\n📊 Sample:", sample)
            print("📏 STATUS:", status)
            print("=" * 60)

            # 🔴 PUSH ONLY EVERY INTERVAL
            now = time.time()
            if now - last_push_time > PUSH_INTERVAL:
                send_to_blynk(sample, status, health_code)
                last_push_time = now

            sample = {k: None for k in sample}

    except Exception as e:
        print("Error:", e)