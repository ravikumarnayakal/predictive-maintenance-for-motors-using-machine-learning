import serial
import re
import csv

PORT = "COM4"
BAUD = 115200
OUTPUT_FILE = "motor_maintenance_100.csv"
TARGET_SAMPLES = 100

ser = serial.Serial(PORT, BAUD, timeout=2)

print("Collecting maintenance_required data...")

rows = []
current_sample = {}

while len(rows) < TARGET_SAMPLES:
    line = ser.readline().decode(errors="ignore").strip()

    if not line:
        continue

    print("Raw:", line)

    # Detect new block
    if "DATA" in line:
        current_sample = {}
        continue

    # Voltage
    if "Voltage:" in line:
        current_sample["voltage"] = float(re.findall(r"[-+]?\d*\.\d+|\d+", line)[0])

    # RPM
    elif "RPM:" in line:
        current_sample["rpm"] = float(re.findall(r"[-+]?\d*\.\d+|\d+", line)[0])

    # Temperature
    elif "Temperature" in line:
        current_sample["temperature"] = float(re.findall(r"[-+]?\d*\.\d+|\d+", line)[0])

    # Vibration
    elif "Vibration:" in line:
        current_sample["vibration"] = 0 if "No Vibration" in line else 1

    # Accelerometer
    elif "AcX:" in line:
        nums = re.findall(r"-?\d+", line)
        current_sample["acx"] = int(nums[0])
        current_sample["acy"] = int(nums[1])
        current_sample["acz"] = int(nums[2])

    # ✅ If full sample collected → store row
    if len(current_sample) == 7:
        current_sample["label"] = "maintenance_required"
        rows.append(current_sample)
        print(f"Saved sample {len(rows)}/{TARGET_SAMPLES}")
        current_sample = {}

# ✅ Write to CSV
with open(OUTPUT_FILE, "w", newline="") as f:
    writer = csv.DictWriter(
        f,
        fieldnames=["voltage", "rpm", "temperature", "vibration", "acx", "acy", "acz", "label"]
    )
    writer.writeheader()
    writer.writerows(rows)

print(f"\n✅ Saved {TARGET_SAMPLES} maintenance samples to {OUTPUT_FILE}")