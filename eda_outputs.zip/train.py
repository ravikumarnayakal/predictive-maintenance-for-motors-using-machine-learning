import os
import joblib
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    classification_report,
    confusion_matrix,
    ConfusionMatrixDisplay,
    roc_curve,
    auc,
)

# ---------------- CONFIG ----------------
DATA = "motor_dataset_raw.csv"   # your feature dataset
TARGET = "label"                   # or "label"
MODEL_SVM = "svm_model.pkl"
MODEL_RF = "rf_model.pkl"

TEST_SIZE = 0.25
RANDOM_STATE = 42
POSITIVE_LABEL_NAME = "maintenance_required"  # for ROC if using string labels
# ----------------------------------------


def safe_makedirs(path):
    if path and not os.path.exists(path):
        os.makedirs(path)


def encode_target_if_needed(y):
    if y.dtype == object:
        le = LabelEncoder()
        y_enc = le.fit_transform(y.astype(str))
        return y_enc.astype(int), le.classes_
    return y.astype(int).values, None


def plot_histograms(df, outdir, max_cols=12):
    safe_makedirs(outdir)
    cols = df.select_dtypes(include=[np.number]).columns.tolist()[:max_cols]

    if not cols:
        return

    n = len(cols)
    ncols = 3
    nrows = int(np.ceil(n / ncols))

    plt.figure(figsize=(12, 4 * nrows))

    for i, c in enumerate(cols, 1):
        plt.subplot(nrows, ncols, i)
        plt.hist(df[c].dropna().values, bins=30)
        plt.title("Histogram: {}".format(c))

    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "histograms.png"), dpi=200)
    plt.close()


def plot_correlation_heatmap(df, outdir, max_features=25):
    safe_makedirs(outdir)
    num = df.select_dtypes(include=[np.number])

    if num.shape[1] < 2:
        return

    variances = num.var().sort_values(ascending=False)
    use_cols = variances.head(max_features).index.tolist()
    corr = num[use_cols].corr()

    plt.figure(figsize=(10, 8))
    plt.imshow(corr.values, aspect="auto")
    plt.colorbar()
    plt.xticks(range(len(use_cols)), use_cols, rotation=90)
    plt.yticks(range(len(use_cols)), use_cols)
    plt.title("Correlation Heatmap")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "correlation_heatmap.png"), dpi=200)
    plt.close()


def plot_class_balance(y, outdir, class_names=None):
    safe_makedirs(outdir)
    unique, counts = np.unique(y, return_counts=True)

    if class_names is None:
        labels = [str(u) for u in unique]
    else:
        labels = [class_names[u] for u in unique]

    plt.figure(figsize=(6, 4))
    plt.bar(labels, counts)
    plt.title("Class Balance")
    plt.tight_layout()
    plt.savefig(os.path.join(outdir, "class_balance.png"), dpi=200)
    plt.close()


def plot_confusion(y_true, y_pred, title, outpath):
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm)
    fig, ax = plt.subplots(figsize=(5, 4))
    disp.plot(ax=ax, colorbar=False)
    ax.set_title(title)
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close(fig)


def plot_roc_binary(y_true, y_score, title, outpath):
    fpr, tpr, _ = roc_curve(y_true, y_score)
    roc_auc = auc(fpr, tpr)

    plt.figure(figsize=(6, 5))
    plt.plot(fpr, tpr, label="AUC = {:.3f}".format(roc_auc))
    plt.plot([0, 1], [0, 1], linestyle="--")
    plt.title(title)
    plt.xlabel("FPR")
    plt.ylabel("TPR")
    plt.legend(loc="lower right")
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()


def plot_rf_feature_importance(rf_model, feature_names, outpath, top_k=20):
    if not hasattr(rf_model, "feature_importances_"):
        return

    importances = rf_model.feature_importances_
    idx = np.argsort(importances)[::-1][:top_k]

    top_feats = [feature_names[i] for i in idx]
    top_imps = importances[idx]

    plt.figure(figsize=(8, 6))
    plt.barh(top_feats[::-1], top_imps[::-1])
    plt.title("RF Feature Importance")
    plt.tight_layout()
    plt.savefig(outpath, dpi=200)
    plt.close()


# ---------------- MAIN ----------------
df = pd.read_csv(DATA)

if TARGET not in df.columns:
    raise ValueError("TARGET '{}' not found".format(TARGET))

X = df.drop(columns=[TARGET])
y_raw = df[TARGET]

y, class_names = encode_target_if_needed(y_raw)

# ---------- EDA ----------
EDA_DIR = "eda_outputs"
safe_makedirs(EDA_DIR)

print("\nDataset shape:", df.shape)
print("\nMissing values:\n", df.isna().sum().sort_values(ascending=False).head())

plot_class_balance(y, EDA_DIR, class_names)
plot_histograms(X, EDA_DIR)
plot_correlation_heatmap(X, EDA_DIR)

# ---------- Split ----------
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=TEST_SIZE,
    random_state=RANDOM_STATE,
    stratify=y
)

# ---------- Models ----------
svm_model = Pipeline([
    ("scaler", StandardScaler()),
    ("svm", SVC(kernel="rbf", C=10, gamma="scale", probability=True, random_state=RANDOM_STATE))
])

rf_model = RandomForestClassifier(
    n_estimators=300,
    max_depth=10,
    min_samples_leaf=5,
    class_weight="balanced",
    random_state=RANDOM_STATE
)

# ---------- Train ----------
svm_model.fit(X_train, y_train)
rf_model.fit(X_train, y_train)

# ---------- Predict ----------
svm_pred = svm_model.predict(X_test)
rf_pred = rf_model.predict(X_test)

print("\n========== SVM ==========")
print(classification_report(y_test, svm_pred))
print(confusion_matrix(y_test, svm_pred))

print("\n========== RF ==========")
print(classification_report(y_test, rf_pred))
print(confusion_matrix(y_test, rf_pred))

# ---------- Plots ----------
EVAL_DIR = "eval_outputs"
safe_makedirs(EVAL_DIR)

plot_confusion(y_test, svm_pred, "SVM Confusion Matrix", os.path.join(EVAL_DIR, "cm_svm.png"))
plot_confusion(y_test, rf_pred, "RF Confusion Matrix", os.path.join(EVAL_DIR, "cm_rf.png"))

# ROC only for binary
if len(np.unique(y)) == 2:
    svm_score = svm_model.predict_proba(X_test)[:, 1]
    rf_score = rf_model.predict_proba(X_test)[:, 1]

    plot_roc_binary(y_test, svm_score, "SVM ROC", os.path.join(EVAL_DIR, "roc_svm.png"))
    plot_roc_binary(y_test, rf_score, "RF ROC", os.path.join(EVAL_DIR, "roc_rf.png"))

# RF Feature Importance
plot_rf_feature_importance(rf_model, X.columns.tolist(), os.path.join(EVAL_DIR, "rf_feature_importance.png"))

# ---------- Save Models ----------
joblib.dump(svm_model, MODEL_SVM)
joblib.dump(rf_model, MODEL_RF)

print("\nSaved:", MODEL_SVM)
print("Saved:", MODEL_RF)
print("\nEDA saved to:", os.path.abspath(EDA_DIR))
print("Evaluation plots saved to:", os.path.abspath(EVAL_DIR))