import serial

ser = serial.Serial('COM4', 115200, timeout=3)

print("Listening on COM3 at 115200 baud...\n")

while True:
    if ser.in_waiting:
        data = ser.readline().decode(errors='ignore').strip()
        print(data)