import pandas as pd

normal = pd.read_csv("motor_normal_100.csv")
fault = pd.read_csv("motor_maintenance_100.csv")

df = pd.concat([normal, fault], ignore_index=True)
df.to_csv("motor_dataset_raw.csv", index=False)

print("✅ Combined dataset saved as motor_dataset_raw.csv")
print(df["label"].value_counts())